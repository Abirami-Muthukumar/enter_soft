<?php return array (
  'name.required' => 'The name field is required.',
);
