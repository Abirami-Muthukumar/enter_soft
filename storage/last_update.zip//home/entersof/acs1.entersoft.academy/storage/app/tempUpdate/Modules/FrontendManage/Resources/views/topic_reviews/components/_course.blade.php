{{--@php--}}
{{--    $jd = json_decode($row->course_title);--}}
{{--    $title = $jd->{userLocal()};--}}
{{--@endphp--}}

{{--{{$title}}--}}
