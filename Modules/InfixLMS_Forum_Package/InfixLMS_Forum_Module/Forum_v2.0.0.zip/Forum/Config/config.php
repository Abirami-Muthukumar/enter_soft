<?php

return [
    'name' => 'Forum'
];
