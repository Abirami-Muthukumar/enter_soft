<?php

namespace Modules\Forum\Entities;

use Illuminate\Database\Eloquent\Model;

class ForumReplyLike extends Model
{
    protected $guarded = [];
}
