<?php

namespace Modules\Forum\Entities;

use Illuminate\Database\Eloquent\Model;

class ForumLike extends Model
{
    protected $guarded = [];
}
